{{/*
ODG vendoring patch — see scripts/patch-perses-chart.sh. Overrides image assembly so
OCM's flat "host/path/image" + tag works:
  image.repository + image.tag set        → used verbatim (OCM relocation)
  else image.registry/name/version        → upstream split assembly (defaults)
Sidecar uses sidecar.image.repository/tag if repository is a full host/path string
(contains "/"), else the chart's registry+repository:tag.
*/}}
{{- define "perses-app.image" -}}
{{- $img := .Values.image -}}
{{- if and $img.repository $img.tag }}
{{- if $img.digest }}{{ $img.repository }}:{{ $img.tag }}@{{ $img.digest }}{{ else }}{{ $img.repository }}:{{ $img.tag }}{{ end }}
{{- else if $img.digest -}}
{{ $img.registry }}/{{ $img.name }}:{{ $img.version | default .Chart.AppVersion }}@{{ $img.digest }}
{{- else -}}
{{ $img.registry }}/{{ $img.name }}:{{ $img.version | default .Chart.AppVersion }}
{{- end }}
{{- end }}

{{- define "perses-app.sidecar.image" -}}
{{- $img := .Values.sidecar.image -}}
{{- if and $img.repository $img.tag (regexMatch "/" $img.repository) }}
{{- if $img.digest }}{{ $img.repository }}:{{ $img.tag }}@{{ $img.digest }}{{ else }}{{ $img.repository }}:{{ $img.tag }}{{ end }}
{{- else if $img.digest -}}
{{ $img.registry | default $.Values.image.registry }}/{{ $img.repository }}:{{ $img.tag }}@{{ $img.digest }}
{{- else -}}
{{ $img.registry | default $.Values.image.registry }}/{{ $img.repository }}:{{ $img.tag }}
{{- end }}
{{- end }}
